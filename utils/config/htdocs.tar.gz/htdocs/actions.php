<?php
if (!defined('sec')) {
	die('Try Harder!');
}
if (isset($_POST['ajax']) && isset($_POST['action'])) {
	$aaction = trim(strip_tags($_POST['action']));
	$script = isset($_POST['script']) && in_array($_POST['script'], array('mana-nat-full', 'mana-nat-simple', 'start-noupstream', 'start-noupstream-eap'))	?	$_POST['script']	:	'';
	switch($aaction):
	case 'startmana':
		switch($script):
			case 'mana-nat-full':
				$o = shell_exec('start-mana-full &> /sdcard/htdocs/mana.log &');
				$res = array('status' => 100, 'message' => 'MANA started.');
				break;
			case 'mana-nat-simple':
				$o = shell_exec('start-mana-simple &> /sdcard/htdocs/mana.log &');
				$res = array('status' => 100, 'message' => 'MANA started.');
				break;
			case 'start-noupstream':
				$o = shell_exec('start-mana-noup &> /sdcard/htdocs/mana.log &');
				$res = array('status' => 100, 'message' => 'MANA started.');
				break;
			case 'start-noupstream-eap':
				$o = shell_exec('start-mana-noupeap &> /sdcard/htdocs/mana.log &');
				$res = array('status' => 100, 'message' => 'MANA started.');
				break;
			default:
				$res = array('status' => 200, 'message' => 'Invalid script.');
				break;
		endswitch;
	break;
	case 'stopmana':
		switch($script):
			case 'mana-nat-full':
				$o = shell_exec('stop-mana');
				$res = array('status' => 100, 'message' => 'MANA stopped.');
				break;
			case 'mana-nat-simple':
				$o = shell_exec('stop-mana');
				$res = array('status' => 100, 'message' => 'MANA stopped.');
				break;
			case 'start-noupstream':
				$o = shell_exec('stop-mana');
				$res = array('status' => 100, 'message' => 'MANA stopped.');
				break;
			case 'start-noupstream-eap':
				$o = shell_exec('stop-mana');
				$res = array('status' => 100, 'message' => 'MANA stopped.');
				break;
			default:
				$res = array('status' => 200, 'message' => 'Invalid script.');
				break;
		endswitch;
	break;
	case 'getexternalip':
		$o = shell_exec("curl http://myip.dnsomatic.com");
		$res = array('status' => 100, 'message' => $o);
		break;
	case 'starthostapd':
		$o = shell_exec('start-hostapd &');
		$res = array('status' => 100, 'message' => 'hostapd started.');
		break;
	case 'stophostapd':
		$o = shell_exec('stop-hostapd');
		$res = array('status' => 100, 'message' => 'hostapd stopped.');
		break;
	case 'startdnsmasq':
		$o = shell_exec('start-dnsmasq');
		$res = array('status' => 100, 'message' => 'Dnsmasq started.');
		break;
	case 'stopdnsmasq':
		$o = shell_exec('stop-dnsmasq');
		$res = array('status' => 100, 'message' => 'Dnsmasq stopped.');
		break;
	case 'startbadusb':
		$o = shell_exec('start-badusb &> /sdcard/htdocs/badusb.log &');
		$res = array('status' => 100, 'message' => 'Attack started.');
		break;
	case 'stopbadusb':
		$o = shell_exec('stop-badusb');
		$res = array('status' => 100, 'message' => 'Attack stopped.');
		break;
	case 'iptaction1':
		$o = shell_exec('start-iptables');
		$res = array('status' => 100, 'message' => 'iptables action 1 started.');
		break;
	case 'iptflush':
		$o = shell_exec('iptables-flush');
		$res = array('status' => 100, 'message' => 'iptables flushed');
		break;
	case 'startkalissh';
	$o = shell_exec('start-ssh');
	$res = array('status' => 100, 'message' => 'Kali SSH started.');
	break;
	case 'stopkalissh';
	$o = shell_exec('stop-ssh');
	$res = array('status' => 100, 'message' => 'Kali SSH stopped.');
	break;
	case 'startkalidnsmasq';
	$o = shell_exec('start-dnsmasq');
	$res = array('status' => 100, 'message' => 'Kali Dnsmasq started.');
	break;
	case 'stopkalidnsmasq';
	$o = shell_exec('stop-dnsmasq');
	$res = array('status' => 100, 'message' => 'Kali Dnsmasq stopped.');
	break;
	case 'startkalihostapd';
	$o = shell_exec('start-hostapd &');
	$res = array('status' => 100, 'message' => 'Kali hostapd started.');
	break;
	case 'stopkalihostapd';
	$o = shell_exec('stop-hostapd');
	$res = array('status' => 100, 'message' => 'Kali hostapd stopped.');
	break;
	case 'startkalivpn';
	$o = shell_exec('start-vpn');
	$res = array('status' => 100, 'message' => 'Kali VPN started.');
	break;
	case 'stopkalivpn';
	$o = shell_exec('stop-vpn');
	$res = array('status' => 100, 'message' => 'Kali VPN stopped.');
	break;

	case 'startkaliapache';
	$o = shell_exec('start-apache');
	$res = array('status' => 100, 'message' => 'Apache started.');
	break;
	case 'stopkaliapache';
	$o = shell_exec('stop-apache');
	$res = array('status' => 100, 'message' => 'Apache stopped.');
	break;
	case 'resetusb';
	$o = shell_exec('stop-badusb');
	$res = array('status' => 100, 'message' => 'Resetting USB.');
	break;
	case 'startkalimetasploit':
		$o = shell_exec('start-msf');
		$res = array('status' => 100, 'message' => 'Metasploit started.');
		break;
	case 'stopkalimetasploit':
		$o = shell_exec('stop-msf');
		$res = array('status' => 100, 'message' => 'Metasploit stopped.');
		break;
	default:
		$res = array('status' => 200, 'message' => 'Unrecognized action!');
		break;
		endswitch;
		echo json_encode($res);
		die;
}
