<div id="cl-wrapper" class="fixed-menu">
	<div class="cl-sidebar">
		<div class="cl-toggle"><i class="fa fa-bars"></i></div> <!-- Hamburger Menu Toggle -->
		<div class="cl-navblock">
			<div class="menu-space">
				<div class="content">
				<!-- Main menu -->
				<ul class="cl-vnavigation">
				  <li class="<?php if ($selected_k === 'home'): echo 'active'; endif;?>"><a href="index.php?k=home"><i class="fa fa-home"></i><span>Nethunter Panel Home</span></a></li>
				  <li class="<?php if ($selected_k === 'kaliservices'): echo 'active'; endif;?>"><a href="index.php?k=kaliservices"><i class="fa fa-gears"></i><span>Kali Service Control</span></a></li>
				  <li class="<?php if ($selected_k === 'hid'): echo 'active'; endif;?>"><a href="index.php?k=hid"><i class="fa fa-keyboard-o"></i><span>HID Keyboard Attack</span></a></li>
				  <li class="<?php if ($selected_k === 'badusb'): echo 'active'; endif;?>"><a href="index.php?k=badusb"><i class="fa fa-road"></i><span>BadUSB MITM Attack</span></a></li>
				  <li class="<?php if ($selected_k === 'mana'): echo 'active'; endif;?>"><a href="index.php?k=mana"><i class="fa fa-signal"></i><span>MANA Evil Access Point</span></a></li>
				  <li class="<?php if ($selected_k === 'dnsmasq'): echo 'active'; endif;?>"><a href="index.php?k=dnsmasq"><i class="fa fa-sitemap"></i><span>Dnsmasq Service</span></a></li>
				  <li class="<?php if ($selected_k === 'hostapd-config'): echo 'active'; endif;?>"><a href="index.php?k=hostapd-config"><i class="fa fa-rocket"></i><span>Hostapd Service</span></a></li>
				  <li class="<?php if ($selected_k === 'iptables'): echo 'active'; endif;?>"><a href="index.php?k=iptables"><i class="fa fa-table"></i><span>Iptables Configuration</span></a></li>
				</ul> <!-- .cl-vnavigation -->
				</div> <!-- .content -->
			</div> <!-- .menu-space -->
		</div> <!-- .cl-navblock -->
	</div> <!-- .cl-sidebar -->
