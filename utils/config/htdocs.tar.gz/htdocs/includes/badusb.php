<?php
	if (isset($_POST['action']) && $_POST['action'] == 'update'):
		$interface = isset($_POST['interface'])	?	trim(strip_tags($_POST['interface']))	:	'';
		if (!empty($interface)):
			if (ctype_alnum($interface)) {
				$con = file_get_contents($files['badusb']['path']);
				$con = preg_replace( '/^INTERFACE=(.*)$/m', 'INTERFACE='.$interface, $con);
				file_put_contents($files['badusb']['path'], $con);
				$message = 'Options updated!';
			} else {
				$message = 'Invalid input!';
			}
		else:
			$message = 'Invalid input!';
		endif;
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['badusb']['path'], $new_source);
		$message = 'Source updated!';
	endif;
	$con = file_get_contents($files['badusb']['path']);
	preg_match( '/^INTERFACE=(.*)$/m', $con, $match );
	$interface = $match[1];
?>
        <div class="block-flat">
          <div class="header">
            <h3>BadUSB MITM Attack</h3>
			<p>This is our implementation of the <a href="https://srlabs.de/badusb/" target="_blank">BadUSB</a> attack as demonstrated at Black Hat USA 2014. Enabling this USB mode will turn your device with its OTG USB cable into a network interface when plugged into a target computer. Connecting the USB cable to a PC will force all traffic from that PC (Windows or Linux) through the NetHunter device, where the traffic can be MITM'd.<br />

			<font color="red"><b>Configuration:</b></font> The default config should work as-is. Your Nethunter device will use the 10.0.0/24 address space and provide DHCP and DNS services to the target system.
			<ol>
				<li>Start the BadUSB attack using the button below.</li>
				<li>Connect your OTG USB cable to a target PC and wait for a couple of minutes.</li>
				<li>Once completed, stop the BadUSB attack to regain normal USB functionality.</li>
			</ol>
          </div>
          <div class="content">

<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#options" role="tab" data-toggle="tab">Options</a></li>
	<li class=""><a href="#source" role="tab" data-toggle="tab">Source</a></li>
</ul>
<div class="tab-content">
	<div id="options" class="tab-pane fade in active pane-padded">
		<form action="/index.php" method="POST">
			<input type="hidden" name="action" value="update" />
			<input type="hidden" name="k" value="badusb" />
			<div class="form-group">
				<label for="input-interface">Interface:</label>
				<input id="input-interface" class="form-control" type="text" name="interface" placeholder="<?php echo $interface;?>" value="<?php echo $interface;?>" />
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
	<div id="source" class="tab-pane fade in pane-padded">
		<form action="index.php#source" method="POST">
			<input type="hidden" name="k" value="badusb" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="15"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
	<p></p>
</div>
<div class="bottom-buttons-group">
	<a href="javascript:void(0);" onclick="return startStop('startbadusb');"><input class="btn btn-success btn-sm" type="button" value="Start BadUSB Attack" name="commit"></a>
	<a href="javascript:void(0);" onclick="return startStop('stopbadusb');"><input class="btn btn-danger btn-sm" type="button" value="Stop BadUSB Attack" name="commit"></a>
</div>
