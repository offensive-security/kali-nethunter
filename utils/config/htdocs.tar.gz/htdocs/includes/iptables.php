<?php
	if (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files[$selected_k]['path'], $new_source);
		$message = 'Source updated!';
	endif;
	$con = file_get_contents($files[$selected_k]['path']);
	preg_match('/^iptables -A FORWARD -i (.*) -o (.*) -j ACCEPT(.*)$/m', $con, $match);
	$wlan0 = $match[1];
	$wlan1 = $match[2];
?>
        <div class="block-flat">
          <div class="header">							
            <h3>Iptables Setup Config</h3>
			<p>Easily set up NAT or use <a href="http://www.netfilter.org/projects/iptables/" target="_blank">iptables</a> rules to route traffic.</p>
          </div>
          <div class="content">

<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#source" role="tab" data-toggle="tab">Source</a></li>
</ul>
<div class="tab-content">
	<div id="source" class="tab-pane fade in active pane-padded">
		<form action="index.php#source" method="POST">
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="15"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
	<p></p>
</div>
<div class="bottom-buttons-group">
	<a href="javascript:void(0);" onclick="return startStop('iptaction1');"><input class="btn btn-success btn-sm" type="button" value="Run Iptables" name="commit"></a>
	<a href="javascript:void(0);" onclick="return startStop('iptflush');"><input class="btn btn-success btn-sm" type="button" value="Flush" name="commit"></a>
</div>
