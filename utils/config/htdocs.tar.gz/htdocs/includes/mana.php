        <div class="block-flat">
          <div class="header">
            <h3>MANA Evil Access Point</h3>
			<p>This is the configuration page for <a href="https://github.com/sensepost/mana" target="_blank">MANA</a>, an evil access point implementation by Sensepost. The various MITM logs get written to the <b>/var/lib/mana-toolkit</b> directory in the Kali chroot.<br />
			<font color="red"><b>Configuration:</b></font> The default config should work as-is but you can also choose the type of attack to perform if you wish.</p>
          </div>
          <div class="content">

<?php
if (isset($_REQUEST['tab']) && in_array($_REQUEST['tab'], array('hostapd-karma', 'dhcpd', 'dnsspoof', 'mana-nat-full', 'mana-nat-simple', 'start-noupstream', 'start-noupstream-eap'))):
	$selected_tab = $_REQUEST['tab'];
else:
	$selected_tab = 'hostapd-karma';
endif;
if (!in_array($selected_tab, array('mana-nat-full', 'mana-nat-simple', 'start-noupstream', 'start-noupstream-eap'))):
	$selected_tab_mana = 'mana-nat-full';
else:
	$selected_tab_mana = $selected_tab;
endif;
?>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<ul class="nav navbar-nav nav-tabs no-border" role="tablist">
			<li class="<?php if ($selected_tab == 'hostapd-karma'): echo "active";endif; ?>"><a href="#hostapd-karma" role="tab" data-toggle="tab">hostapd-karma.conf</a></li>
			<li class="<?php if ($selected_tab == 'dhcpd-mana'): echo "active";endif; ?>"><a href="#dhcpd" role="tab" data-toggle="tab">dhcpd.conf</a></li>
			<li class="<?php if ($selected_tab == 'dnsspoof'): echo "active";endif; ?>"><a href="#dnsspoof" role="tab" data-toggle="tab">dnsspoof.conf</a></li>
			<!--
			<li class="<?php if ($selected_tab == 'startmana'): echo "active";endif; ?>"><a href="#startmana" role="tab" data-toggle="tab">mana-nat-full.sh</a></li>
			 -->
			<li class="dropdown<?php if (in_array($selected_tab, array('mana-nat-full', 'mana-nat-simple', 'start-noupstream', 'start-noupstream-eap'))): echo " active";endif; ?>">
          		<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span id="ddvalue"><?php echo $selected_tab_mana;?></span> <span class="caret"></span></a>
          		<ul class="dropdown-menu" role="menu">
		            <li><a href="#mana-nat-full" role="tab" data-toggle="tab" onclick="manaScriptSelect('mana-nat-full');" >mana-nat-full</a></li>
		            <li><a href="#mana-nat-simple" role="tab" data-toggle="tab" onclick="manaScriptSelect('mana-nat-simple');">mana-nat-simple</a></li>
		            <li><a href="#start-noupstream" role="tab" data-toggle="tab" onclick="manaScriptSelect('start-noupstream');">start-noupstream</a></li>
		            <li><a href="#start-noupstream-eap" role="tab" data-toggle="tab" onclick="manaScriptSelect('start-noupstream-eap');">start-noupstream-eap</a></li>
          		</ul>
			</li>
		</ul>
	</div><!-- /.container-fluid -->
</nav>

<div class="tab-content no-border">
	<div id="hostapd-karma" class="tab-pane fade in<?php if ($selected_tab == 'hostapd-karma'): echo " active";endif; ?>">
		<?php include $files['hostapd-karma']['include'];?>
	</div>
	<div id="dhcpd" class="tab-pane fade in<?php if ($selected_tab == 'dhcpd'): echo " active";endif; ?>">
		<?php include $files['dhcpd-mana']['include'];?>
	</div>
	<div id="dnsspoof" class="tab-pane fade in<?php if ($selected_tab == 'dnsspoof'): echo " active";endif; ?>">
		<?php include $files['dnsspoof']['include'];?>
	</div>

	<div id="mana-nat-full" class="tab-pane fade in<?php if ($selected_tab == 'mana-nat-full'): echo " active";endif; ?>">
		<?php include $files['mana-nat-full']['include'];?>
	</div>
	<div id="mana-nat-simple" class="tab-pane fade in<?php if ($selected_tab == 'mana-nat-simple'): echo " active";endif; ?>">
		<?php include $files['mana-nat-simple']['include'];?>
	</div>
	<div id="start-noupstream" class="tab-pane fade in<?php if ($selected_tab == 'start-noupstream'): echo " active";endif; ?>">
		<?php include $files['start-noupstream']['include'];?>
	</div>
	<div id="start-noupstream-eap" class="tab-pane fade in<?php if ($selected_tab == 'start-noupstream-eap'): echo " active";endif; ?>">
		<?php include $files['start-noupstream-eap']['include'];?>
	</div>

</div>

<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
	<p></p>
</div>

<div class="bottom-buttons-group">
	<a href="javascript:void(0);" onclick="return startStopMana('start');"><input class="btn btn-success btn-sm" type="button" value="Start mana" name="commit"></a>
	<a href="javascript:void(0);" onclick="return startStopMana('stop');"><input class="btn btn-danger btn-sm" type="button" value="Stop mana" name="commit"></a>
</div>
<script>
	

</script>
