<?php
	$values = array('interface', 'dhcp-range');
	if (isset($_POST['action']) && $_POST['action'] == 'update'):
		$con = file_get_contents($files[$selected_k]['path']);
		foreach ($values as $v):
			if (isset($_POST[$v])):
				$new_value = $v.'='.strip_tags(trim($_POST[$v]));
				$con = preg_replace('/^'.$v.'=(.*)$/m', $new_value, $con);
			endif;
		endforeach;
		preg_match_all('/^#{0,1}address=(.*)?/m', $con, $currenta);
		foreach ($_POST['address'] as $k => $a):
			$a = trim(strip_tags($a));
			$con = str_replace($currenta[0][$k], $a, $con);
		endforeach;
		preg_match_all('/^dhcp-option=(.*)?/m', $con, $currentdhcpo);
		foreach ($_POST['dhcpoption'] as $k => $a):
		$a = trim(strip_tags($a));
		$con = str_replace($currentdhcpo[0][$k], 'dhcp-option='.$a, $con);
		endforeach;
		file_put_contents($files[$selected_k]['path'], $con);
		$message = 'Options updated!';
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files[$selected_k]['path'], $new_source);
		$message = 'Source updated!';
	endif;
	$con = file_get_contents($files[$selected_k]['path']);
	foreach ($values as $v):
		preg_match( '/^'.$v.'=(.*)?/m', $con, $match );
		if (isset($match[1])):
			$$v = $match[1];
		else:
			$$v = '';
		endif;
	endforeach;
	preg_match_all('/^#{0,1}address=(.*)?/m', $con, $addresses);
	$address[0] = $addresses[0][0];
	$address[1] = $addresses[0][1];
	preg_match_all('/^dhcp-option=(.*)?/m', $con, $dhcpoptions);
	$dhcpoption[0] = $dhcpoptions[1][0];
	$dhcpoption[1] = $dhcpoptions[1][1];
?>
        <div class="block-flat">
          <div class="header">
            <h3>Dnsmasq Service Config</h3>
			<p><a href="http://www.thekelleys.org.uk/dnsmasq/doc.html" target="_blank">Dnsmasq</a> is a lightweight DNS forwarder and DHCP server that can easily be configured to provide DNS and DHCP services to a small network.</p>
          </div>
          <div class="content">

<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#options" role="tab" data-toggle="tab">Options</a></li>
	<li class=""><a href="#source" role="tab" data-toggle="tab">Source</a></li>
</ul>
<div class="tab-content">
	<div id="options" class="tab-pane fade in active pane-padded">
		<form action="/index.php" method="POST">
			<input type="hidden" name="action" value="update" />
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<div class="form-group">
				<label for="input-address0">address:</label>
				<input id="input-address0" class="form-control" type="text" name="address[]" placeholder="address" value="<?php echo $address[0];?>" />
			</div>
			<div class="form-group">
				<label for="input-address1">address:</label>
				<input id="input-address1" class="form-control" type="text" name="address[]" placeholder="address" value="<?php echo $address[1];?>" />
			</div>
			<?php foreach ($values as $v):?>
				<div class="form-group">
					<label for="input-<?php echo $v;?>"><?php echo $v.":";?></label>
					<input id="input-<?php echo $v;?>" class="form-control" type="text" name="<?php echo $v;?>" placeholder="<?php echo $v;?>" value="<?php echo $$v;?>" />
				</div>
			<?php endforeach;?>
			<div class="form-group">
				<label for="input-dhcpoption0">dhcp option:</label>
				<input id="input-dhcpoption0" class="form-control" type="text" name="dhcpoption[]" placeholder="dhcp option" value="<?php echo $dhcpoption[0];?>" />
			</div>
			<div class="form-group">
				<label for="input-dhcpoption1">dhcp option:</label>
				<input id="input-dhcpoption1" class="form-control" type="text" name="dhcpoption[]" placeholder="dhcp option" value="<?php echo $dhcpoption[1];?>" />
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
	<div id="source" class="tab-pane fade in pane-padded">
		<form action="index.php#source" method="POST">
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update source" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
	<p></p>
</div>
<div class="bottom-buttons-group">
	<a href="javascript:void(0);" onclick="return startStop('startdnsmasq');"><input class="btn btn-success btn-sm" type="button" value="Start dnsmasq" name="commit"></a>
	<a href="javascript:void(0);" onclick="return startStop('stopdnsmasq');"><input class="btn btn-danger btn-sm" type="button" value="Stop dnsmasq" name="commit"></a>
</div>
