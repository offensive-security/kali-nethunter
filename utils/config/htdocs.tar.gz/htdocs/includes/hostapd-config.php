<?php
	$values = array('interface', 'bssid', 'ssid', 'channel', 'enable_karma');
	if (isset($_POST['action']) && $_POST['action'] == 'update'):
		$con = file_get_contents($files[$selected_k]['path']);
		foreach ($values as $v):
			if (isset($_POST[$v])):
				$new_value = $v.'='.strip_tags(trim($_POST[$v]));
				$con = preg_replace('/^'.$v.'=(.*)$/m', $new_value, $con);
			endif;
		endforeach;
		file_put_contents($files[$selected_k]['path'], $con);
		$message = 'Options updated!';
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files[$selected_k]['path'], $new_source);
		$message = 'Source updated!';
	endif;
	$con = file_get_contents($files[$selected_k]['path']);
	foreach ($values as $v):
		preg_match( '/^'.$v.'=(.*)$/m', $con, $match );
		if (isset($match[1])):
			$$v = $match[1];
		else:
			$$v = '';
		endif;
	endforeach;
?>
        <div class="block-flat">
          <div class="header">
            <h3>hostapd Service Config</h3>
			<p><a href="http://wireless.kernel.org/en/users/Documentation/hostapd" target="_blank">hostapd</a> is a user space daemon for wireless access point and authentication servers. You can use hostapd to easily create a wireless access point using these configuration options:</p>
          </div>
          <div class="content">

<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#options" role="tab" data-toggle="tab">Options</a></li>
	<li class=""><a href="#source" role="tab" data-toggle="tab">Source</a></li>
</ul>
<div class="tab-content">
	<div id="options" class="tab-pane fade in active pane-padded">
					<form action="/index.php" method="POST">
						<input type="hidden" name="action" value="update" />
						<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<?php foreach ($values as $v):?>
				<div class="form-group">
					<label for="input-<?php echo $v;?>"><?php echo $v.":";?></label>
					<input id="input-<?php echo $v;?>" class="form-control" type="text" name="<?php echo $v;?>" placeholder="<?php echo $v;?>" value="<?php echo $$v;?>" />
				</div>
			<?php endforeach;?>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
	<div id="source" class="tab-pane fade in pane-padded">
		<form action="index.php#source" method="POST">
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="15"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
	<p></p>
</div>
<div class="bottom-buttons-group">
	<a href="javascript:void(0);" onclick="return startStop('starthostapd');"><input class="btn btn-success btn-sm" type="button" value="Start hostapd" name="commit"></a>
	<a href="javascript:void(0);" onclick="return startStop('stophostapd');"><input class="btn btn-danger btn-sm" type="button" value="Stop hostapd" name="commit"></a>
</div>
