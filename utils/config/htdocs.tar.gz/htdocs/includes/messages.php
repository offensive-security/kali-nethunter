<?php if (!empty($message)):?>
	<div class="alert alert-info" id="main-alert" role="alert">
		<p><?php echo $message;?></p>
	</div>
	<?php unset($message);?>
<?php endif;?>