<?php
$kaliSshStatus			= shell_exec('sh /system/xbin/check-kalissh') == 0	?	' not-running'	:	'';
$kaliDnsmasqStatus		= shell_exec('sh /system/xbin/check-kalidnsmq') == 0	?	' not-running'	:	'';
$kaliHostapdStatus		= shell_exec('sh /system/xbin/check-kalihostapd') == 0	?	' not-running'	:	'';
$kaliVpnStatus			= shell_exec('sh /system/xbin/check-kalivpn') == 0	?	' not-running'	:	'';
$kaliApacheStatus		= shell_exec('sh /system/xbin/check-kaliapache') == 0	?	' not-running'	:	'';
$kaliMetaspolitStatus		= shell_exec('sh /system/xbin/check-kalimetasploit') == 0	?	' not-running'	:	'';
$kaliBeefXSSStatus		= shell_exec('sh /system/xbin/check-kalibeef-xss') == 0	?	' not-running'	:	'';
?>




        <div class="block-flat">
          <div class="header">							
            <h3>Kali Service Control</h3>
			<p>Various Kali network services can be started and stopped via the buttons in this part of the interface.<br>
			<strong><font color="red">Warning:</font></strong> Ensure you have changed any default passwords before enabling remote access to your device.</p>
          </div>
          <div class="content">
              <form class="form-horizontal group-border-dashed" action="#" style="border-radius: 0px;">
              <div class="form-group">
                <label class="col-sm-2 control-label">Kali SSH</label>
                <div class="col-sm-6">		
					<input class="switch startkalissh" id="startkalissh"  type="checkbox" data-on-color="success" data-off-color="danger" <?php if ( $kaliSshStatus !=  ' not-running' ) echo 'checked'; ?>>
					<div id="kalisshmessage"></div>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Kali Dnsmasq</label>
                <div class="col-sm-6">
					<input class="switch startkalidnsmasq" id="startkalidnsmasq"  type="checkbox" data-on-color="success" data-off-color="danger" <?php if ( $kaliDnsmasqStatus !=  ' not-running' ) echo 'checked'; ?>>
					<div id="kalidnsmasqmessage"></div>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Kali Hostapd</label>
                <div class="col-sm-6">
					<input class="switch startkalihostapd" id="startkalihostapd"  type="checkbox"  data-on-color="success" data-off-color="danger"  <?php if ( $kaliHostapdStatus !=  ' not-running' ) echo 'checked'; ?>>
					<div id="kalihostapdmessage"></div>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Kali VPN</label>
                <div class="col-sm-6">
					<input class="switch startkalivpn" id="startkalivpn"   type="checkbox" data-on-color="success" data-off-color="danger" <?php if ( $kaliVpnStatus !=  ' not-running' ) echo 'checked'; ?>>
					<div id="kalivpnmessage"></div>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Kali Apache</label>
                <div class="col-sm-6">
					<input class="switch startkaliapache" id="startkaliapache" type="checkbox" data-on-color="success" data-off-color="danger" <?php if ( $kaliApacheStatus !=  ' not-running' ) echo 'checked'; ?>>
					<div id="kaliapachemessage"></div>
                </div>
              </div>			  
              <div class="form-group">
                <label class="col-sm-2 control-label">Kali Metasploit</label>
                <div class="col-sm-6">
					<input class="switch startkalimetasploit" id="startkalimetasploit" type="checkbox" data-on-color="success" data-off-color="danger" <?php if ( $kaliMetaspolitStatus !=  ' not-running' ) echo 'checked'; ?>>
					<div id="kalimetasploitmessage"></div>
                </div>
              </div>
               <div class="form-group">
                <label class="col-sm-2 control-label">Kali Beef-XSS</label>
                <div class="col-sm-6">
                                        <input class="switch startkalibeef-xss" id="startkalibeef-xss" type="checkbox" data-on-color="success" data-off-color="danger" <?php if ( $kaliBeefXSSStatus !=  ' not-running' ) echo 'checked'; ?>>
                                        <div id="kalibeef-xssmessage"></div>
                </div>
              </div>
            </form>
          </div>
        </div>
